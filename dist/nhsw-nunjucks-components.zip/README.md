# NHSW Nunjucks components v0.1.1

Every NHSW component as a Nunjucks macro (one per component, under
`components/<name>/macro.njk`), styled after the GOV.UK/NHS.UK frontend
libraries. Requires the NHSW Sass build (`nhsw.css`) to be loaded on the
page — these macros only render markup, not styles.

## Use with your own Nunjucks setup

Point your FileSystemLoader's search path at the extracted `components/`
directory, then import whatever you need:

```js
const nunjucks = require('nunjucks');
nunjucks.configure('components', { autoescape: true });
```

```njk
{% from "button/macro.njk" import nhswButton %}
{{ nhswButton({ text: "Continue", classes: "nhsw-button--primary" }) }}
```

Or pull every macro in at once with `{% import "all-components.njk" as nhsw %}`.

## Use the bundled loader

`nunjucks.config.js` is the same environment config this library's own
tests use — copy it alongside `components/` and call
`configure({ ... }).renderString(...)` / `.render(...)`.

## Docs

Every component's params and worked examples are documented in its
`<name>.yaml` file, and `components/README.md` covers the shared
conventions (form-group wrapping, label/hint/error composition, the
maxlength/character-count contract, etc).
