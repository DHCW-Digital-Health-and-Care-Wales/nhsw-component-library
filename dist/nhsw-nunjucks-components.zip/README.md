# NHSW Nunjucks components v0.1.3

Every NHSW component as a Nunjucks macro (one per component, under
`components/<name>/macro.njk`), styled after the GOV.UK/NHS.UK frontend
libraries. These macros only render markup — you'll also need:

- The NHSW Sass build (`nhsw.css`) loaded on the page, for styles.
- `nhsw-behaviours.js` loaded on the page, for interactivity — character
  count, conditionally revealed content, tabs, the expander, file upload
  status, and the session-timeout countdown all depend on it. The date
  picker needs `nhsw-date-picker.js` separately. Both ship from the same
  release as this package.

## Use with your own Nunjucks setup

Point your FileSystemLoader's search path at the extracted `components/`
directory, then import whatever you need:

```js
const nunjucks = require('nunjucks');
nunjucks.configure('components', { autoescape: true });
```

```njk
{% from "button/macro.njk" import nhswButton %}
{{ nhswButton({ text: "Continue", classes: "nhsw-button--primary" }) }}
```

Or pull every macro in at once with `{% import "all-components.njk" as nhsw %}`.

## Use the bundled loader

`nunjucks.config.js` is the same environment config this library's own
tests use — copy it alongside `components/` and call
`configure({ ... }).renderString(...)` / `.render(...)`.

## Docs

Every component's params and worked examples are documented in its
`<name>.yaml` file, and `components/README.md` covers the shared
conventions (form-group wrapping, label/hint/error composition, the
maxlength/character-count contract, etc).
